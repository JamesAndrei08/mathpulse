/* Authored by: Vivianne Alano
Company: Sync
Project: MathPulse
Feature: [SMP-002] Settings
Description: focuses on the settings section, providing easy-to-use buttons for sound, background music, and vibration adjustments
 */

import 'package:flutter/material.dart';
import 'main.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: Center(
        child: Container(
          width: 300,
          height: 600,
          decoration: BoxDecoration(
            color: Color(0xFFC6DCBA), // Green backdrop
            borderRadius: BorderRadius.circular(20.0), // Rounded corners
          ),
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SettingToggle(
                  title: 'Sound',
                  imageUrl:
                      'https://lh3.googleusercontent.com/pw/AP1GczOp7EMDowjHVCNY8UGP8L-oc1-qXZquCI-zdn04AL_VU0p3wkSjm62GoV1TKfl0fnzhvyzqmXiK-sfGpAEYRN_JpmO4hwjOP5RIoGnxGvZFpFuX90kem9bJSP3OGZG20nbmeP0CUQx5Ua_sDWLtosrb87Rc1dvtiS0zvohhkfC_vtaSybef0w_nNajVat4RnZw8NeOU1ThX7fyRVIkVFtv_Fj2musHonx87ltX_HlLRWnXPb15dIsLuwEpG09gjthM8q9OHE23jbwXYuuv92kMPGM02Yg1V59LtcSpGy-UdN4azQ10W2Uj59ed7keDYYSv2atc6zFVFnvehTGj6VrCezklv0VSIdjxUtlsc9I0fvHnsqbqXhtC1BrnUHAa3jYcywh__Os2GZopzyFNjEB1zqTTsgORG1lQ-sRP-XzSh1_7LI59hUu7Lh5slg9dFbhQ-aIF76JoHT3d_aY_qjlh7Zk9zyMOFHC4Ry1g2YgoKJ_RZ74sdkE4GhI5g_kM_hHNYFWnEpEZWrxd0nLSF60Wse-aF8Lm1VUTlyHEFnpyjIr8jmwcAb5i_oDM1xzbjR6y0ezFJBy-FMkGQqK4qAtlLvvzLZU_UhgL6WM-5NccgOza5VBRYQH2kxmaTIMmLDuYeWq2sBdN-1A2izJ-KWPT0azOiz25R6CxvqeGdQSHOw9rysKiSSusdymwceZFx7JM73AL8dDv7g_THCC4Us7MVGYZWDOuzfIFBNGmvQXxSX9BD-kPOAD6a4EggdzmuwglEMdtW7re1Vh0k2rwDPxJJUfyU5FK294sFj4klSkhLHQ26cBbS3kJcsCXfikDty_F5XbMZbIgNTBGIU4kEo2S_AV1a1XaD_sf1X6mfCc14592TTrS0IB77BaFzgszc19yEShf5z5ewBziiT6FzohvC=w913-h913-s-no-gm?authuser=0',
                ),
                SizedBox(height: 20.0),
                SettingToggle(
                  title: 'BGM',
                  imageUrl:
                      'https://lh3.googleusercontent.com/pw/AP1GczPTsioHuDzvuJqo7-5xe9KCWimcEMgjctBYg7A1PFWb0CoZfB7vdeQDEV5RQOyKJGifowudWZK9DUv-_QtM_UOvx3Py2XrB_rU5x40ta_3P9ieHhQRA18HKllulgxr6MbyJfHT1v3yDo_ca67ztNuLEyeuJNf7l9M_fcSTwZmjxBY3c074Q80Exek3NoB10tZ2GqAGuY-S9VEPMn3dbRf5djficbJcGnZExdOF57PkOlrpl-pP4ylHi7MdWc05CHSh-lFopVtHvCU3627RCh-6oguzRkGksL6b8ozUPYb1q_7bM9pipFpP7uL7WgO94FTRUn8FqH1kyNo4hzcgvqoKpvfYO9P4rrYMmYA4v8NyrJxsZGkefuXgIs4-ER7cUks8JKPrz0a2GtGOwZp8PQPWXrnCt0YcViZzksTi1SiQeUgg71BYGCAgcokyWGzrOKhhSDQY2FFBYmjSQ9VrSeGZ_RXts9Fz67RWJ4arzNMPf7wfIiv-qZheExySWJVRw2Dea0IwVwRgL7X96JSJXuIHMTMBo_RRU6c-qqKxiEyO_ZquSNVfdQIKIiGq1GS6nm9QYKTF6w79TtnpuH0oTQysEqV6yMJCEuK0YsEJIHxXM2o6-CMLu6tx1WElndJ3U3WlbNzOVobC8hVBY55TFoSVLqqWjQXe9-JUAVRLhAkkTelCUmw9SJuChmN8aEkUrSwKZpsrsj-yNMGpd03n_6D9Qilse62GvxI4R9P9hcBnH-Qr1-D00O1qZDXpLJrDeV87Y_0nLoLLqnNdep1clGWh6Gey6eSDUKvD1rN8LZorYi3gAqw-9V8Qf9IXekDc0XD_aMstbDuLQ9paatxjP6zKH7QZ5NvhKVdCYQyWy4CGCk30e2orzS_RLdz6yXw0GnLX78lFCqgnTJJugRaS-mTwb=w913-h913-s-no-gm?authuser=0',
                ),
                SizedBox(height: 20.0),
                SettingToggle(
                  title: 'Vibrate',
                  imageUrl:
                      'https://lh3.googleusercontent.com/pw/AP1GczPXTekshuMrmjY1_QxnMuBpfaodc72f0T74pGqHyZa81ONooM9YDk2PY47P5V54AC8gbV2dhAye9DDjn6ejCTop1wPvtirhVHafS5uUHePj7u2xKbI8bqmD7kHLnSBKa_s0MEexNyP0x8fPkUqdYAbb3JghxhqqSI7MQII8eh2dDyTCoeuGz1fXi2ZSDn5j2vATtwdmcHzIgmWLbR3q9XGbiAhaSoBthuL6uXlNF1oehRPJdcR1Cv05V_XleWcJynW5kI_nxBniIM9zWlDxV25gNVDH8efuXl_9Wq2K1qcbJ5nQmrU9nq9xfHabduIys79uRdrRc76UuSgpuEe4n59aKM4T2jKgY_McG-RIW4kjnNNSaN5pikg6v_FtbD3WS-Uci7LHD0Oe_FGBsH3ef76HILTt4T6yA85Rov_UG8dN7AD-QWP-YAUtqOALnxmpnOBLYQf7bOw2Pv2zTr7GmWReLHCBqVbtd5S0iYO6gS84KLDqsre1NzK0qqM3VhwnlYYRtMKvN4G89ES4Nl0sRlMk0yQUTXULQaViHbzSu6rDM6FJrhZUbzKvUSIXoZqlQIlOkKxhZFC1bdM4xLhH9yK2RHwkRBZhRo_kGWxtrBKAKPmFcqWG1VM2VK7O5q8XmQo5mHWpY7tOffnydF9RpqjBwyvjYPuoa9SpfQPnGJKfv2_c359g_PQtZ1fDDe-aLEgD9VjXfVpRPF4tLTh5b4a4BzFG2G1CUbULamQI-F6XC_JZuhh5ZLi0LzoV8S5LjIQ5AEdl61T7H5mYCWXsr_hDsZkk_YNfu5c_huyFSzy61dFCwE7hQxQC42YnEOLn4pUjbh0l0Obg2s1PaQ2osOkUoVdYFB6FAD_CCrsZ73q0ydrihrQr4zN95btIf-6-cxdelWB0TN-YsBIJ1SpfMAtm=w913-h913-s-no-gm?authuser=0',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class SettingToggle extends StatefulWidget {
  final String title;
  final String imageUrl;

  const SettingToggle({
    Key? key,
    required this.title,
    required this.imageUrl,
  }) : super(key: key);

  @override
  _SettingToggleState createState() => _SettingToggleState();
}

class _SettingToggleState extends State<SettingToggle> {
  bool _isEnabled = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Image.network(
          widget.imageUrl,
          width: 100, // Adjust width as needed
          height: 100, // Adjust height as needed
          // Add any additional image properties as needed
        ),
        SizedBox(height: 10.0),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20.0), // Oval shape
            color: Colors.grey[200], // Light grey background color
          ),
          child: Row(
            children: [
              Spacer(),
              Text(
                widget.title,
                style: TextStyle(
                  fontFamily: 'Alata', // Set font to Alata
                  fontSize: 18, // Increase font size
                  fontWeight: FontWeight.bold,
                ),
              ),
              Spacer(),
              Switch(
                value: _isEnabled,
                onChanged: (value) {
                  setState(() {
                    _isEnabled = value;
                  });
                },
              ),
              Spacer(),
            ],
          ),
        ),
      ],
    );
  }
}
