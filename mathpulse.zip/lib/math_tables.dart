/* Authored by: Vivianne Alano
Company: Sync
Project: MathPulse
Feature: [SMP-004] Math Tables
Description: offers a range of tables for multiplication, division, addition, and subtraction to improve mathematical skills
 */

import 'package:flutter/material.dart';
import 'start.dart';

class MathTablesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 200, // Adjust the height of the photo
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(
                      'https://lh3.googleusercontent.com/pw/AP1GczNUonsOOHhFA-VwErf_6awse2yEpz6Y5sdfyjkqsc-sWl_knKXIpQxPgSOpQef0a7lmQc8r__9VjBcAnBEAoyHaiWLQRbPFP9tbfOo1Q1zryH_yLUGoNFqGwKyySkhL9Xh72BV9tQq5VmsS1XE1OUZ54zacdk_LPJbwTc4b1xr6KxWDqRwYjD2db92Cl1iUMRx02nahYDyvmBAL6Bd7hLJh0n2L6RI2J0Y45GfjusLp4J6eh69hVBopkGLngncovPrMg1f_VsHDlExKdMjfLl-XXrlql7kRAY90f2h3wAQQ5uf2oqiug2wurO4B3LMtIzNz4ed6ersH9bUwTRUyGwY3XhTDvjOKEMaR0X_Ep4FAiiHEX0n-YCfXTzUEX5JErcPTTdHwGSJuyqrOnU4t4yiLjGNuvQJnOioaGMoK9Llus6sTbFQBJFNDVS-eTSrxWjByXfAfp_1ZXXDlLNImjU4TANQb35rDVy50pwIXVLSxjuTJUhK_uALFW0UT_2CuW9ETuNKUImJdWVQUY4a52dcaG9_yTdb0AWZXOZqBd_RPEgyJK2Vr7w7ZWIrWEA0ukE2vulgRJcL0VAXbhNw-DbLUcvoGRAavpDPh0me4spAO2BJnR5tci5iPYbe85XyIPZ84GyUBIia-apfeGH-349KZOng58iJU7GDOWSDCnvL5OtATUPB0xN6gLbfKS9rDxPeym9MtcjWlJS7IqRJ6DT7Etv5y9gXsmtTRFUncicVbFjjqmxSvZDwLghn_GSFMPVpajN90QH6WnwMK7KCHaULMy8jik8B-kKAm68IKwfxK9TlpNMfp15pzNswzCwSU8wk0ky4yq_fzptgBMHNGhHwSMzwS4TBQ9O-iee1nOhRDI7pM0Q29yJXyhGck0UTUPmPDsrLvVsvj76s4yG7w33az=w913-h913-s-no-gm?authuser=0'), // Replace with your image URL
                  fit: BoxFit.cover,
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ), // Add some spacing between the image and rectangles
            buildCurvedRectangle(
                'Addition',
                'https://lh3.googleusercontent.com/pw/AP1GczNPxRN9MKSerjQ1GPr5NpDzJAB6BFDYrnpHHbxbEb1DuMe4AjFSK5QFVePDAUHFq4Y0pfvJ8QB2-euJvj7Ik1CF2hNnncv0YIA7I3pDwjudlrFPAiKyiIdk9kjDEvzEj1grXL1aykjKJp2wQvJh8Fk6Mrce2WJUirVT8taVSX2rgAMwx7A_2yO55oWT5AZ2zjeJKINtefGxzeWhN4NCKU5PcufdSawiQTRqOCRm8t91dsE3od1-Od1Fum9xUCG5sOx0_F6yIKcfpHbVn-LlGgSUcCHti-JkKdf_xhs7-UozpS54Mrmmya7rcsZKPq31omK9jy56AprmQxw-vXGqTrVp3YhVJY24g7b_NW6izMbtHC7dk0LPbVaxrJRCSugLVPQQxwcFcfFe2YljShdlIG1ELMEKBhvHjUZ68Pq26yu428j9YwVdrRXQe_DjyfHXS0wTab22ZD1IV_o17oCrlaAh813SxZjk_ax86WrzY2B2kIoSAjNL3GyyMB-JmSwpTmRpetlC1KpGPVJycf076ZtXvl2i0dd7Prhsl8knTmPZVQwOQILm_5HQobnIewYQbKync_Ce-nJiw-26vk45sXpUxFn881AK2CHKTieH9FhSFNyzaWGvPTxMdOh7ShEuKBFrQInAlxLcwD07PJSN6T_IVZReJXkZ6j9VkL51uVcnBsu2ckMREFHAiYgjGN-HXkoNGqdML9USGsUUdnxwB6V9eSt-1Ul3cYyfC9qOc2Gzg-abyVINxKNcqgjXHegl6C-bIyWzyX3CXEr0EDyyaNFgO1W2TY949l7gesitXYGMFyjoOdadLws69c37W-8rGFHUr1iFNqEA7HXxI-fAMXUN9oqwlHY0QRlEmNM2SKnjqppn_1XR-C_q_blC3TpcdMAyY6a2UPcJigjW5XT1iCJf=w913-h913-s-no-gm?authuser=0',
                0xFFFFC5C5,
                120,
                120), // Customize size here
            SizedBox(height: 20), // Add spacing between rectangles
            buildCurvedRectangle(
                'Subtraction',
                'https://lh3.googleusercontent.com/pw/AP1GczPG-as4T6K77sC-5JvhBD8E63DthrB-CXCKBjTK5GesbbX2QaUwszmOzIwR0t4iWihVuVPMtRjXZR_ROXZEYLAUp0RetNtWrvB_OrWmbzoy7QQk_S_x9aZkw1zPxzjAgoRurJVhCb80Nu6wXqP6ChA_Pdr5TKFHFV3PUMNwNWhuM1kWFmtJ1c3cjfukpVASU_08J-rgMcgDnIkNf7RvKTp2WX_snHw_XE_Z7Mta728XnEsZ6bk6z50t7dvwzeAFoCpY-zy6KTBz6ozpRq2lMkTganBRMsmVdWhkGsE6oavpcaYkOV7cn55aYC5STtrQEuVTaMOZ2H5CXlBXeEvdzndXbe-gjX3dcaa6x57N6gFAl37b-ER3CVJjIbu255T1XZKw7fbCytmIHY7Rv87Athftuueij0h_sFPZ9xj-_RAUcJX5ztT_E53tSmFXn0ZhMCsXi1dd7BLf5x--XO_MDO-Cz24ZDcNCbJIY4v99PgZG_grXHDfDu-m83iwrlplEj4sIQSlXOlZiSeXDwfoXfZzvMLkIxOwAFYdoRZa-i1h5ffq_negfMaxLXy5nuXL8sWM1_8csrau1pJOgwOyS0cT0v46EzE_Z8Me_vpUkOeLfCes4-Uhg4qMtsSM-TQJ6tW6Nn_n4baJjECxHaeclDwt6rVTcu_7i6_Jggpn7ruCgXEAK-NsxmA4pC59pv0Bm53tEMJsgq2MMCvgnyLCym1iM_rgpqjYz6hndZpwUn3lmCter6Hb2TzqhTBaWxT-FgbJaleqZ-p4M8wb2MNSaM7U9BfXYiznBl-26Gd7dnOXvrYd4Pk2TC2rNrJl3DFPLHDH3b877dYVl8rbAfo7BAib32vZ0Dx7rN-I_5RXuMAzkRIVBm1Rof2Yx3T0rsZDcfu-UDILz80RBFRUJrlKzUc-G=w913-h913-s-no-gm?authuser=0',
                0xFFEEF1FF,
                120,
                120), // Customize size here
            SizedBox(height: 20), // Add spacing between rectangles
            buildCurvedRectangle(
                'Multiplication',
                'https://lh3.googleusercontent.com/pw/AP1GczM7GKoMTJRU5uVvSqp0jgaLJufoRuk6-FDMF9sf1gk8s5fwDxLrAhhkaz3QC-1XauO-MFdA0-ZGXWiefIT1MStVxI2dyxrT64Ed9tsGp7j7-2UV3zKETF0FSz2v3WWSORL90q0kOs0uuM3fxb2ZbXjHR8vFsCfhXjXoSIs3WgLp_Q_c-0OkQJ3xh492gfSvAaupj09uTR29k17pploExLB79JkYG7q0uRciKONY82OlNcwA-LzC76_3mJwuIFznEvBr06Z23NO355ZpF8zumIaKuoIXmfFVEk0a9oNKW01xPKEJNV69Ij9TlnDtcOmp2h46seEuO4Ei0hiypNfHqxs8zpL1yUiRy4kPF8GZlfdBwdtBjrXm1XuukiTYbhp44Vt2y2vgR3UUFvDwjAZBByFwZFRYsxh1UFoAehwjuQK5ANfJ-zhYuSNiCi9Hr9ohVBXalKOzpcJn-iu49X48eDEcaMyQNB43BA4KlFGtnC-0xzs3OfznRVFstcFPRBfHNyNIw-v05iBsFhsw592cjUwa4bnDmUp64-y34EsZts_eBEZv34zas2fuxj-0FNtbt2-XF4Mjx3GIlss5DMpZ7YBYEXpSsmxBYz3c45cm1EVH3lqFkd86b7ysnBEm_l5I7ei88UvhNL7I-WkGnMdGzFotzGkv5CFSqgsyJQ8ZNJdpyfe8yDEdVFiDnHtmpmg5Y_6S4ulKOVQYESDsYKUYfZU9iaC2xDIP2O2HkLKrZ0gbM8uxSUUEaYJt_-rvPf7qt6pybbBwwWnCQW1RhuumXxsp9ehahuHkegWse92xqkKV61koAeY6hph_EnXRH6O_2vBQglZmEGcNpyv0LptvKDyJmsCFw0XIb5hGjvWiLtuK3-8SyOTzn7DlTXf0mF71cB98BBlbpG8kgn-R0IGK8pBC=w913-h913-s-no-gm?authuser=0',
                0xFFFFF6DC,
                120,
                120), // Customize size here
            SizedBox(height: 20), // Add spacing between rectangles
            buildCurvedRectangle(
                'Division',
                'https://lh3.googleusercontent.com/pw/AP1GczM7oLu0TAQwJbTDFtS0QLw7RAfMS43V6F5kT4tFg-z4I7yGNTcy_kdYCM37iGOaQ-AY6p8MKR2dzY4g6TVfAaLica1QfN8Pr4nDEcQJuvQaAn516Kjy579njVj1j-nq-pTjaG83fYQLajDl6BA3nZCQ1lYOXr957K1fNjHSZN3mUEe0_EfuRo6aderzU9bCfYan4uPBjaxOFatG7jsJG_GB2fiamAbNcEXmORrTe1wiukrovPFnxtmiInNAi8TOIWSBuilosSN6FhvNWrqsg2aIO_rD65mzJwxEh8tvdrJqjfLJCfwC9yV2WoE3_8uf6uecq7Y25kHmOhdwBHrexRwW7gBEThrJ3QgKpQNdNU9-kvJAx9QrKLDwN1XD1HIXQ_zAZtSmSH_zXzaCq5mBC1IPDc-O6-s-ZdCKEfXGteT4coZ5R8Fv4rfdWoOKic1uuFCjR4MSITq5YWSMEuoNC3sKa4BEf18os-1ZcdUnlLe7lywvrhI3ol0-24tO_7rw1oLPm5uBzV2uzrzJlL0W-g5u29EARclHvHH_OrvyvwiSDCHnKg1jIFZcGg_ZX1afr8jPTfCBUuARgNHEqLVaysISdJDZEbuh3PErklT2nv3HzAkEfjW6phfNmea9m57cINV5QKR4ce3VVWiP0Twb_JKxyKzZLwNGcjsRFxXV3Z2z2YVQp_gYZnD5uVXK9zcqsTRlgz83NySWJTYBUu7ST79ha0EDskL9kWdqvx4OULB-tuPJ0LaACml4R-XpinUmS_Yro3fYOQz4b4CbhIuukKSjVPVSmWm9A_pHYGV_3_mCB8lGXE4UCnBXjVpgBx6WcKiIyXjwMtF60PrAuFDGwIDigsldzY0Kk0ZseQakNtVnvenq7iNWVP0JOdOD5BQUNVuc9oJBgRIyO5UJIYzIJDX7=w913-h913-s-no-gm?authuser=0',
                0xFFE8EFCF,
                100,
                100), // Customize size here for subtraction
          ],
        ),
      ),
    );
  }

  Widget buildCurvedRectangle(String text, String imageUrl, int colorValue,
      double imageWidth, double imageHeight) {
    Color color = Color(colorValue);
    return ClipPath(
      clipper: ShapeBorderClipper(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      child: Container(
        height: 160, // Fixed height for the container
        color: color,
        child: SizedBox(
          height: 160, // Fixed height for the SizedBox
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.network(
                imageUrl,
                width: imageWidth,
                height: imageHeight,
              ),
              SizedBox(height: 10), // Add spacing between image and text
              Text(
                text,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
