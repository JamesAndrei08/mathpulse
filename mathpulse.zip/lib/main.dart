/* Authored by: Vivianne Alano
Company: Sync
Project: MathPulse
Feature: [SMP-001] Home Screen
Description: a straightforward home screen for the app game, including basic options like settings and play
 */

import 'package:flutter/material.dart';
import 'settings_screen.dart';
import 'start.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My App',
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Top Background Photo
          Positioned(
            top: MediaQuery.of(context).size.height * 0.5 - 450,
            left: MediaQuery.of(context).size.width * 0.5 - 240,
            child: Image.network(
              'https://lh3.googleusercontent.com/pw/AP1GczMOAsVQUDB-cp7PL88B4DqgthPOo65ABYnwf9ZNeVB1w0WkonOBzb49BizhhCDZ_MjtUPGRO8A-u7QCpGZDNCPfy5zRUJufNRucnn15H96g-oMJdifvhNEfUvdc6-RBsA5uUQj-TK42Y_tm8z9dI0HoiKKDvkDuo7PEwgx-M-M9P3yz8HfqqnvEYad4GSCtLuIGuNC7isl2Pa3BCxBSSgg39hpiQ6aM3M6ZuSL4MjMls6rCL4GrgHkwQf0G_ajSSYK9R8mgRtTNYs6ItXaRGPQIA6le3AGVARfpzzm-vnap2PTMneQUDWDYOXCqngmJ9tO8ioyNHAsYhU-Dy4-SH3r7Wj_7xO2o8aCKoQlNb-8Ur0Jzvjfu249WcdIe-mwZl2QoQ3KtiidcGJUJweIVsRVi54oOD6MC-tSoQGovB6bQ8EGmjM06wcWhVImpSNiQrFyMw7CJlReLoAlOEqmm9dd8pSoWQm0XfttSCNKFGPN99vUaMB2l50mnJCwhnrKMVagkvnY-4z5BPQiHnixjFb1OOomqpOXjR_LE7LyoT4HjTZSP4SD97cUxCP75sxBRzJ1Hr_BjztGL4PtHTRjeMM7Gn9P-07BFOr1FXnleC1Ux7Nm53ZXNwCQDKSZeN--wfCbm3M3D8oAjab8Ng0vNa5cqvOjiziWi3yJrBr07Yju1BREwq8I2g11rEvNXQR-Zk5kDv7jQdLwIVFJE9UYJirnUTv9FaLVujIWrdutDWiiLtKcM2OMCoyxxwSnkCTw_UldUe_yVkPIkvj1nQrk8xT5EYNAm-PPf42Ddo02PCvbfwO1RKqhONzVfHSBbdUlKLRB8_jLwqu4uswNq7LPv_JrPEVrllLd3SNCscDFg1g9qKnx50-mD-8JUAvOt0tGLu_YO9ButK7D8gQaKCdQAqgU=w913-h913-s-no-gm?authuser=0', // URL to your top background photo
              width: 490,
              height: 500,
              fit: BoxFit.cover,
            ),
          ),
          // Bottom Background Photo
          Positioned(
            top: MediaQuery.of(context).size.height * 0.5 - 40,
            left: MediaQuery.of(context).size.width * 0.5 - 240,
            child: Image.network(
              'https://lh3.googleusercontent.com/pw/AP1GczOhQoDjqbqU02o6pAFg3uXY5EKZnaISYfAFE7VOzpDZqx1__LedAOxnJ2iFhI0fNdtfIGOuc0PPOPseAkFe_RlJrx2cmsIXb2-NSe6UmruzmXvv6iCGuML50AoIGRQHYPL8uIa5pNoTHD-RuJ8JsZHOmFQkkWnHb5YiPyt8uoDcAObe77CWUJIPwpJs98MfV_5SigYlI-ea9QiiyrYWvm98UIyQK1JZ9OWFvNlpfMnUSV2x6ZDv_DXNLRPFJIWdlXvAMT62JWWpesJVals26ZjTN38_Kvi-q6DxUwmacZ3lo-fE_er0e7XQqubhgBbuUPEXxKa2LJ8dfR28Ym4x6Okhyvc6UnkO82o9Ljr-NowrTE-zoDjixDMlKhSuLluNLSCG4A1YEcYi2FhQDtP6f71TttyOHZhzHCUSa_e0EybSmaBxpBXyj3X43p1omjq0U9dXfs1xZmf2mW--Y2le5GqYD9XS_gB5YNqCS-STh8pR09iKIRvTo15RAlMcE4TenC7h9AUystnPqhhFKgH6eUzpi-pzU_OgSe-ePA5KwKjro56rQqvGYYTpdctWyrfvwgztIMbWM3cv4o-Xzzbc4i8GrQcYS2HuOO2nZOjYVXMqisygaZn7jEtAu1sYOlo16hXIfEJKlQRuWokoJKZdA2vn6XJDC7c6YdQJdCa2rMbcZ2rVJnrVfNxzSJHLjXOPwliZLLpN0mX4awZQ1mw9cUe5_bGIMscRzN_AQo_UBXMZJRI-BA1LnJ6MmHOVyXQ_ZkQX-equF7syirQ3GpAY0TwCM2vjeAHPTtALTL3vgMdrRAuCB5gaPe1vy0F-bQF9umZQDWdjB1l8bGPAMF-nt7zhAFT2-xBMoDOuLhEZaaaXOLXJdos0xi_f7DjNvpTN23RRK4sUzPRNXaE_tLDC13YZ=w913-h913-s-no-gm?authuser=0', // URL to your bottom background photo
              width: 490,
              height: 500,
              fit: BoxFit.cover,
            ),
          ),
          // Backdrop Rectangle
          Positioned(
            top: MediaQuery.of(context).size.height * 0.5 - 200,
            left: MediaQuery.of(context).size.width * 0.5 - 175,
            child: Container(
              width: 350,
              height: 500,
              decoration: BoxDecoration(
                color: Color(0xFF85586F),
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  // Start Button
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => StartScreen()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            40.0), // 40.0 gives a rounder shape
                      ),
                      padding:
                          EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                      elevation: 5, // Add elevation for 3D effect
                      primary:
                          Colors.white, // Change the primary color to white
                    ),
                    child: Text(
                      'START',
                      style: TextStyle(
                        fontFamily: 'Alata',
                        fontSize: 20,
                        color: Colors.black, // Change the text color to black
                      ),
                    ),
                  ),
                  SizedBox(height: 10.0),
                  // Settings Button
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => SettingsScreen()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            40.0), // 40.0 gives a rounder shape
                      ),
                      padding:
                          EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                      elevation: 5, // Add elevation for 3D effect
                      primary:
                          Colors.white, // Change the primary color to white
                    ),
                    child: Text(
                      'SETTINGS',
                      style: TextStyle(
                        fontFamily: 'Alata',
                        fontSize: 20,
                        color: Colors.black, // Change the text color to black
                      ),
                    ),
                  ),
                  SizedBox(height: 10.0),
                  // Exit Button
                  ElevatedButton(
                    onPressed: () {
                      // Add functionality for Exit button
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                            40.0), // 40.0 gives a rounder shape
                      ),
                      padding:
                          EdgeInsets.symmetric(horizontal: 50, vertical: 20),
                      elevation: 5, // Add elevation for 3D effect
                      primary:
                          Colors.white, // Change the primary color to white
                    ),
                    child: Text(
                      'EXIT',
                      style: TextStyle(
                        fontFamily: 'Alata',
                        fontSize: 20,
                        color: Colors.black, // Change the text color to black
                      ),
                    ),
                  ),
                  SizedBox(height: 20.0),
                ],
              ),
            ),
          ),
          // Logo
          Positioned(
            top: MediaQuery.of(context).size.height * 0.5 - 340,
            left: MediaQuery.of(context).size.width * 0.5 - 235,
            child: Image.asset(
              'https://lh3.googleusercontent.com/pw/AP1GczOhQoDjqbqU02o6pAFg3uXY5EKZnaISYfAFE7VOzpDZqx1__LedAOxnJ2iFhI0fNdtfIGOuc0PPOPseAkFe_RlJrx2cmsIXb2-NSe6UmruzmXvv6iCGuML50AoIGRQHYPL8uIa5pNoTHD-RuJ8JsZHOmFQkkWnHb5YiPyt8uoDcAObe77CWUJIPwpJs98MfV_5SigYlI-ea9QiiyrYWvm98UIyQK1JZ9OWFvNlpfMnUSV2x6ZDv_DXNLRPFJIWdlXvAMT62JWWpesJVals26ZjTN38_Kvi-q6DxUwmacZ3lo-fE_er0e7XQqubhgBbuUPEXxKa2LJ8dfR28Ym4x6Okhyvc6UnkO82o9Ljr-NowrTE-zoDjixDMlKhSuLluNLSCG4A1YEcYi2FhQDtP6f71TttyOHZhzHCUSa_e0EybSmaBxpBXyj3X43p1omjq0U9dXfs1xZmf2mW--Y2le5GqYD9XS_gB5YNqCS-STh8pR09iKIRvTo15RAlMcE4TenC7h9AUystnPqhhFKgH6eUzpi-pzU_OgSe-ePA5KwKjro56rQqvGYYTpdctWyrfvwgztIMbWM3cv4o-Xzzbc4i8GrQcYS2HuOO2nZOjYVXMqisygaZn7jEtAu1sYOlo16hXIfEJKlQRuWokoJKZdA2vn6XJDC7c6YdQJdCa2rMbcZ2rVJnrVfNxzSJHLjXOPwliZLLpN0mX4awZQ1mw9cUe5_bGIMscRzN_AQo_UBXMZJRI-BA1LnJ6MmHOVyXQ_ZkQX-equF7syirQ3GpAY0TwCM2vjeAHPTtALTL3vgMdrRAuCB5gaPe1vy0F-bQF9umZQDWdjB1l8bGPAMF-nt7zhAFT2-xBMoDOuLhEZaaaXOLXJdos0xi_f7DjNvpTN23RRK4sUzPRNXaE_tLDC13YZ=w913-h913-s-no-gm?authuser=0', // URL to your bottom background photo
              width: 480,
              height: 450,
            ),
          ),
        ],
      ),
    );
  }
}
