/* Authored by: Vivianne Alano
Company: Sync
Project: MathPulse
Feature: [SMP-004] Math Tables
Description: offers a range of tables for multiplication, division, addition, and subtraction to improve mathematical skills
 */

import 'package:flutter/material.dart';

class MathTablesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Math Tables'),
      ),
      body: Stack(
        children: [
          Positioned(
            top: MediaQuery.of(context).size.height * 0.5 - 400,
            left: MediaQuery.of(context).size.width * 0.5 - 163,
            child: Container(
              width: 330, // Customize width
              height: 330, // Customize height
              child: Image.network(
                'https://lh3.googleusercontent.com/pw/AP1GczPhu0inl1O2YdZtZcmG81yulofI8gqqmBdVXCsug7gpSbMacCSzg7aCi3_c5Tfzq4dSy8hTslmk35x-hf1v4odZ7Fvxr5022p4DK0Z1lg3xewyoYmjl3IFEanaeBTR8ZC2R_EK4y1n_q7ksKVNOOlLIXnilMbNzv8TqubVWDF3X5uTKG26twSBM545aadA7JjOSrZNNgRIvSZxNq4wA-30hDaMmiiKdjLez4O2jWHEdA_T1Hbt28wzJUpitWZjouYKe3pR7lOp6iT8kKin8BXy9fur34Vn84uAtemSWu7C77YKeYGp7s8YwsH6EpU3w0UdNvF0QnUVuWjS5V8USeEAuDQjzyV685cIDxF1loIU60v1jvmAEKSOEsMR3iGP3KOBBz3kvFlhIIjcYYmlBY2jBzpn09_0Cbxek33RC3HpbEixxJRrd4l2NGrF07W6TZp7ixhdqkRAgw0qe9nMKyABZ3CJDt7yexEss4ga_4ZGCVSHMEoJoB68T8EI_OF-A4eFErClkjlzJGqmmXfPzFt_iLSpDjMgafSyoX_eddCvdlZ6ikgu8mpPHhHaDui1LPHMeBOGT3lb0DG4sTxmr_5LBJEbJuHd-1KG-2g6qOltEbKL1Se3MXK6TR6AyJ4yE7uM2dmLj8TVPKjq2c_WowBAl71Prw2ouhHLrP-XcHyMaTiCq_UgvPNwlYrtH41kKdxcmUh0oWgG3pp9ZWXTlNTd3yrpU720J0K9HmEuKstfFcqG8SPOlJnfyrMfBtyba6enJwxmgVOelQoF4biVeqg-5cGq6w-uz5fiF5wcsW2V2PVEkkZXfotSWeCEtkgF4swez51M_cu0i-gnn5EwvNr_FYPdC4ERY4lqL75vNXuw-PdQ8w6PWu_W-2Ytgg16xElpEE5D77YP4buY1nV5uwKks=w929-h929-s-no-gm?authuser=0', // Replace with the actual URL of your image
                fit: BoxFit.cover, // Adjust the fit as needed
              ),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).size.height * 0.5 + -60,
            left: MediaQuery.of(context).size.width * 0.5 - 150,
            child: Container(
              width: 300, // Customize width
              height: 90, // Customize height
              decoration: BoxDecoration(
                color: Color(0xFFC3E2C2), // Rectangle 1 color
                borderRadius: BorderRadius.circular(20),
              ),
              child: Center(
                child: Text(
                  'Problem Solving',
                  style: TextStyle(
                    fontFamily: 'Alata',
                    fontSize: 20,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).size.height * 0.5 + 60,
            left: MediaQuery.of(context).size.width * 0.5 - 150,
            child: Container(
              width: 300, // Customize width
              height: 90, // Customize height
              decoration: BoxDecoration(
                color: Color(0xFFEAD8C0), // Rectangle 2 color
                borderRadius: BorderRadius.circular(20),
              ),
              child: Center(
                child: Text(
                  'Attention',
                  style: TextStyle(
                    fontFamily: 'Alata',
                    fontSize: 20,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).size.height * 0.5 + 180,
            left: MediaQuery.of(context).size.width * 0.5 - 150,
            child: Container(
              width: 300, // Customize width
              height: 90, // Customize height
              decoration: BoxDecoration(
                color: Color(0xFFEED3D9), // Rectangle 3 color
                borderRadius: BorderRadius.circular(20),
              ),
              child: Center(
                child: Text(
                  'Memory',
                  style: TextStyle(
                    fontFamily: 'Alata',
                    fontSize: 20,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
