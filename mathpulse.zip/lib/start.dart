/* Authored by: Vivianne Alano
Company: Sync
Project: MathPulse
Feature: [SMP-003] Start
Description: choose between practicing basic math tables or trying boost modes with memory and problem-solving challenges. Get ready to improve math skills or test cognitive abilities
 */

import 'package:flutter/material.dart';
import 'main.dart';
import 'math_tables.dart';
import 'boost_modes.dart';

class StartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: PageView(
        scrollDirection: Axis.horizontal,
        controller: PageController(),
        children: [
          // First Set of Images
          Stack(
            children: [
              // First Image
              Positioned(
                top: MediaQuery.of(context).size.height * 0.5 - 450,
                left: MediaQuery.of(context).size.width * 0.5 - 190,
                child: Image.network(
                  'https://lh3.googleusercontent.com/pw/AP1GczPPGcdFxmnSmxl1YPBFyzVyObfYe6gJfJXlnreS0CEoZzkMIMSFxTuee4nzYSNF4KXoUgk5Ud3WGDpok20xHAr-obqy6hI8M7nuAF7IICay0Ud-pd3K5H8VtMOQbq9X9trxqvPSGBCLdjPFbuww5yraslog12nQspV8JYWP87HbpyH6E7P0W8QBF78K7vse-5krBiqGRtICjUuPHC2aUvEmdwyL3VoG4NLET4QgMOEnD2h91SDvEbN9xaZNlSAGiFlooZmT5gV0eFs0zOCtjSViyVQTwD1bEyiF5qUCUiZf6UHcg2UYfqtah5yXQ3-Oj6LgmIkLr2kALKObR1Zelkku2lxf5JIc_Q9AmaU84hkQfqz6NBOPxnYNVd2h1l4z24uPIVrTx49AlCBV4UyeNtBn9k0sJsv433HPS6agp6IZ0LTu3qvkczLmZR-hpDc8ZS__xWhJqZXISAg3YdQ_1S9MZadRcUeKeZyu5PMF_H89n0dbjBslwYrgdx8Vuz9gA1fBleIaSHZyiTNZz4luxCM2PQ4wl1ClQ3NyGR9s5SqfRU2nKZ2F6WYO2gBO4vxJdAeJa2_P2L06SOq-hmH01R9RGAxCslhJ_Ig2tjImWLsD6eMETyT01qZTVx9l_6amcECfegOJXKjPYS072sH828XOl4C12KDZV4vpmq1ciiTvY7Fu-XylRZbs7ld6X1DUy6gWlWjxl_IpcA0VsCW2enCd_OJKN3-GSgC3-BQsDKvR1KH4WZjii3bfw0rm_Vqb5QR7cvQzSfeQW25Bf_SF5oLooXyhDHXqxG_DOWbTolvEV3anOzxIX8U4vJsc1KPCKq_soQsZW-XtcdJBtomq2ENzIf928tyV11iyFWE5hFhypVrwkCI0TgCTiot2maagqdoq6QVe7dtaCTsDgHydDnPo=w913-h913-s-no-gm?authuser=0',
                  width: 350, // Adjust width as needed
                  height: 400, // Adjust height as needed
                ),
              ),
              // Second Image
              Positioned(
                top: MediaQuery.of(context).size.height * 0.5 - 260,
                left: MediaQuery.of(context).size.width * 0.5 - 215,
                child: GestureDetector(
                  // Wrap the image with GestureDetector
                  onTap: () {
                    // Navigate to the math_tables.dart screen
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => MathTablesScreen()),
                    );
                  },
                  child: Image.network(
                    'https://lh3.googleusercontent.com/pw/AP1GczNdjNWeje9VSfwFtRtNs_VI5PrpDXae-D_94skUrg84bpkMLldQRtuC9Okeqt1fvUweSpfOoQc7eqUYj4xkHsy5znwcMbwwb3YP6Csw_Vj5-15ip3skghlz33lrsaKa5KSsZ1N_ujoH6D34D00Q3sRuNxO9CRPqIIaQHpPJSWU7ecV4D-ulKv47XyjDd9ROMKNlVHrjs6Esa_ofBI0saEXJxuU7uFztwmINtPV_1tW7gY8a0CJ5lK4Cw3UiVnheI_sXOrp3NLffFjMzryn5e-Mpcqwx3tZttahU8aJcmmVZ-jujj5bZA3WRwDt5win8igNyEAPkLWZB-dMNllh44cWbnu80TAnykddCinsKNShgzAwr69yLZ5skAou9NIqX1tDb95A58-kJLbS1e7MlOuTYoIdn0gmue7s_yTxBt_CglvJSAqHC5Eu0yqOtXJtgpXG1ZJzPJWAZTSF-CgWKOFAm0aQw-OHBK1eHJYjC8xI8auh5izpYY2gBzFGBJ51_9HB2s0NE3hBSCn2TtCFXzEoCHmynZSNdRlbA6BEyF_8uaOBpb4xZDuHKqHTdTjjMGVQpCIXZtOkENZhmUF5nGOQl4IWdQdSVyNUuIntbutxX1EZj4Rc57SQL6J82p-eG_3g8E_w3Ayd8i4rq9IgOzRwzBKw2bGdaBhoztSmYQ5AORB5g4fMuyb4tSTvWd9s9w3Y5_MIqj2z0FWRHrFGPgreT7sNdkJqmJdgShdBttZUIj-Z6TdP8KkNsstT0iXUYUXe0uQwj_5z5OAwrTpdIEqW-q2LsfPEOMaFA2PAqThfwRVGfhNiK-eHWLmJxne-QdtJAYHsEbafXONEaJuT2rPOIJAvm50uodft2RjSMMtC_6qFCNknT6rqOgmQKhILol4L_GFkgCCO9ZGafjcy99pE=w913-h913-s-no-gm?authuser=0',
                    width: 430, // Adjust width as needed
                    height: 750, // Adjust height as needed
                  ),
                ),
              ),
            ],
          ),
          // Second Set of Images
          Stack(
            children: [
              // Third Image
              Positioned(
                top: MediaQuery.of(context).size.height * 0.5 - 400,
                left: MediaQuery.of(context).size.width * 0.5 + -200,
                child: Image.network(
                  'https://lh3.googleusercontent.com/pw/AP1GczMznPnqwmN0xpmJlCAHTFIKFW3EQZ90d1doV9UYf331IAolxXWmkjRguNz1_QoINOa1aFtdkpVVJWlMMAQ1ljbfbBwakJVJnJyEDK13WDisEmRS5rRW7PwhxL0S49MLoXM0lVJ-Z5AbhS3VNQYWDxhhbcUOLkHq1FM26TKV_d7vqobLYHHCRgW3pDGC3OTRJRZ3r5MHsW3Y1X2OU89-q6w5hu9bek5nxlwCjd43CzK_X0sLURKqULPp1YU7pnPAK2eXSiCD71R9AXqjh03udna9w4sGAmk8QZt6osTXejJoVe_E7t-8XGVxOJ9GsTYKxtEzOXG4k5LGob3KfWP3IJHZTKPtTaF5f2CisztnOEcI-BbS0inQCUG-DoRxGVcFK4M2w-SWc2NBjMiIgoO_AMcinpyW1RJ8I2WuNG9Dag7ql7uySoOWOBk1jHqBnzIcIJr26HaTCcnU6Nvwn0t6deSNxIifHZQxizV2ClyjlN6tCZdY40J-K_wFalxeNqLSUf9zSoIM_Xt6_t_Q5-GM8NNCY9ZIKM8M07Kkrh-GcN6rgoKwH228hioVTwHg5n9-3yGu16top9b4hYc7IqXoPwlyt-VzxlcOiJXHSzm6clCb2a2lt1c8y2ddYCq71H78LYu9sKOiSDXAeV6cNFV78VIs5lqcx8UISLVEcw0phJQgnqVsai3fK5jmh6cQ-uwBaAD3ZDXpLrZ2sJDMf2cURqoYUCn0bF3tz6kVjRi5MRt36ADEi_GFR4Hjz4sSJs0ViPtyfXOsbQ6jwRJYNlZqQLAzmRRNQ0R-gLOBRw7JQ6lIvLuFrh9n14UpQHYrksOEXt5821O28FJzf0DoTUcjvTowCWvJaS-_ejaT3UAq8anq-bonVuviMRZcGIFoDFKc-SRBw-c4Dyp2mMMHwjTXeOs=w913-h913-s-no-gm?authuser=0',
                  width: 450, // Adjust width as needed
                  height: 320, // Adjust height as needed
                ),
              ),
              // Fourth Image
              Positioned(
                top: MediaQuery.of(context).size.height * 0.5 - 260,
                left: MediaQuery.of(context).size.width * 0.5 + -215,
                child: GestureDetector(
                  // Wrap the image with GestureDetector
                  onTap: () {
                    // Navigate to the BoostModesScreen page
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => BoostModesScreen()),
                    );
                  },
                  child: Image.network(
                    'https://lh3.googleusercontent.com/pw/AP1GczMHqazKX-5m3_HUjnbq7EljSVlUFR9a8zU8BD8-fvODz_vN68KxQ12DXJVSbXUpBHHSWNGcusiUaBZON7BwbHO5S-nEwaWq9Xl_XrJYztJ4xtCmcdS9_3MefbYyUxeHqZ4IDvK0HR9jhRripa0jgKpKPsJIjUiBICcNDVqO6O68LXBOZoh0vTG_1XDryZ_7oTpCl2MgkhJRIao92qwdue6c2JCYOw0hqL2c0YxN6eE9zVWDqwYj33UXTmtQlPyMYBa7mkPAcnYiIq4wIMbEgFfVCtUWK4DCPvPCKKnnBQeARIHSTKjVs-RpOaRhUNWdiV_Lf6jlw0aGF0idzkPJ_vjiH8sO5RE9LzP-lZXgp0OyC-0z3qYchtCTwbRwf7vqJF-whZcjhFWy2Hq0WMf_ZLdjOdMgpEoN1FOo3CDv4b50VkyCKCwSPe9jGxdmkNTP3UyQrFGlOSSg_UcLRjBE5L6xPifbwmoKRWkW0suf9v3KI_OAsj54bh05z2f_dT7Q6oADLgejUab3pKkJ5YvWg4-W7GZvn_27dlKpwADE1Qs-scqCLhPhBlUR74vJVbcJ3XCY-O52AkqZ20-ez4d7t1bxINiqciL1kxyHrpj3sOOdXbR2RZNzsyuxf3tqBLmWwVz77kjaOJYGNVJasBUordHpIPuNXXR4zNogcrapnD_qbi48yqr61LEKsTdMw6zwP7NpWj2UvZZjODQibxcOVpy3od_2ZcYDaNAbkxjqUhbF6b5NE6A8FHSnE3YmK4ZUreh0fHW20w06K3-Zq4--PJotzKHXTZPjR3q0jd0X-8bKG3nkgykrESbP_K0-ZyhNVD8nYmfNyfawP7lMKBeJhWUgeKMPISGbnEa_P-0r_1J07o_DtsZWqdsSVLk7UB_PuL93kkAVvHaEQx0pgtFccKM=w913-h913-s-no-gm?authuser=0',
                    width: 430, // Adjust width as needed
                    height: 750, // Adjust height as needed
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
