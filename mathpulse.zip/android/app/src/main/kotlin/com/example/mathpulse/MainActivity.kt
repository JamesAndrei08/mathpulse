package com.example.mathpulse

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
